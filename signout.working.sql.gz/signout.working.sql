--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: service; Type: TABLE; Schema: public; Owner: davidrosenberg
--

CREATE TABLE public.service (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    type character varying(8)
);


ALTER TABLE public.service OWNER TO davidrosenberg;

--
-- Name: service_id_seq; Type: SEQUENCE; Schema: public; Owner: davidrosenberg
--

CREATE SEQUENCE public.service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_id_seq OWNER TO davidrosenberg;

--
-- Name: service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: davidrosenberg
--

ALTER SEQUENCE public.service_id_seq OWNED BY public.service.id;


--
-- Name: signout; Type: TABLE; Schema: public; Owner: davidrosenberg
--

CREATE TABLE public.signout (
    id integer NOT NULL,
    intern_name character varying(64) NOT NULL,
    intern_callback character varying(16) NOT NULL,
    service integer NOT NULL,
    oncall boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    addtime timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completetime timestamp without time zone
);


ALTER TABLE public.signout OWNER TO davidrosenberg;

--
-- Name: signout_id_seq; Type: SEQUENCE; Schema: public; Owner: davidrosenberg
--

CREATE SEQUENCE public.signout_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.signout_id_seq OWNER TO davidrosenberg;

--
-- Name: signout_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: davidrosenberg
--

ALTER SEQUENCE public.signout_id_seq OWNED BY public.signout.id;


--
-- Name: service id; Type: DEFAULT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.service ALTER COLUMN id SET DEFAULT nextval('public.service_id_seq'::regclass);


--
-- Name: signout id; Type: DEFAULT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.signout ALTER COLUMN id SET DEFAULT nextval('public.signout_id_seq'::regclass);


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: davidrosenberg
--

COPY public.service (id, name, type) FROM stdin;
1	Med-Breast, Intern #1 (9101)	SOLID
2	Breast, Intern #2 (9102)	SOLID
3	Breast, Intern #3 (9103)	SOLID
4	Breast, Sub-Intern (9182)	SOLID
5	Breast, APP	SOLID
6	GI A, Intern #1 (9160)	SOLID
7	GI A, Intern #2 (9161)	SOLID
8	GI A, Intern #3 (9180)	SOLID
9	GI B, Intern #1 (9164)	SOLID
10	GI B, Intern #2 (9165)	SOLID
11	GI B, Intern #3 (9117)	SOLID
12	GI B, Sub-Intern (9181)	SOLID
13	GU, Intern #1 (9501)	SOLID
14	GU, Intern #2 (9502)	SOLID
15	GU, Intern #3 (9503)	SOLID
16	GU, Sub-Intern #1 (9183)	SOLID
17	GU, NP	SOLID
18	Gen Med, Intern #1 (9171)	LIQUID
19	Gen Med, Intern #2 (9172)	LIQUID
20	Gen Med, Intern #3 (9173)	LIQUID
21	Leukemia A, Intern #1 (9124)	LIQUID
22	Leukemia A, Intern #2 (9125)	LIQUID
23	Leukemia A, Intern #3 (9189)	LIQUID
24	Leukemia A, NP	LIQUID
25	Leukemia A, Sub-Intern (9185)	LIQUID
26	Leukemia B, Intern #1 (9127)	LIQUID
27	Leukemia B, Intern #2 (9128)	LIQUID
28	Leukemia B, NP	LIQUID
29	Leukemia B, Sub-Intern (9186)	LIQUID
30	Lymphoma Green, Intern #1 (9120)	LIQUID
31	Lymphoma Green, Intern #2 (9121)	LIQUID
32	Lymphoma Green, Intern #3 (9115)	LIQUID
33	Lymphoma Green, Intern #3 (9115)	LIQUID
34	Lymphona Green, Sub-Intern (9184)	LIQUID
\.


--
-- Data for Name: signout; Type: TABLE DATA; Schema: public; Owner: davidrosenberg
--

COPY public.signout (id, intern_name, intern_callback, service, oncall, active, addtime, completetime) FROM stdin;
1	David Rosenberg	773-240-3395	1	f	t	2020-09-19 12:30:05.41946	\N
2	Christina Rosenberg	p8281	3	f	t	2020-09-19 12:40:05.426652	\N
3	Schiller Rosenberg	x9100	11	t	t	2020-09-19 12:45:08.428856	\N
6	Alex	1234	22	f	t	2020-09-19 12:49:46.108497	\N
7	Greshma	773-240-3395	18	t	t	2020-09-19 12:55:58.487079	\N
8	Keara English	9101	25	f	t	2020-09-19 12:59:25.16798	\N
5	Benjamin Schrank	123-34-8888	18	f	f	2020-09-19 12:49:29.989271	2020-09-19 16:23:45.745642
4	DavidMichael1	773-240-3395	12	f	f	2020-09-19 12:49:12.863995	2020-09-19 16:23:57.865287
10	Jon doe	1234	31	t	f	2020-09-19 14:08:36.559199	2020-09-19 16:24:20.700535
9	Brian Cahn	123-456-8899	30	t	f	2020-09-19 13:14:39.669749	2020-09-19 16:25:02.784649
\.


--
-- Name: service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: davidrosenberg
--

SELECT pg_catalog.setval('public.service_id_seq', 34, true);


--
-- Name: signout_id_seq; Type: SEQUENCE SET; Schema: public; Owner: davidrosenberg
--

SELECT pg_catalog.setval('public.signout_id_seq', 10, true);


--
-- Name: service service_pkey; Type: CONSTRAINT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_pkey PRIMARY KEY (id);


--
-- Name: signout signout_pkey; Type: CONSTRAINT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.signout
    ADD CONSTRAINT signout_pkey PRIMARY KEY (id);


--
-- Name: signout signout_service_fkey; Type: FK CONSTRAINT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.signout
    ADD CONSTRAINT signout_service_fkey FOREIGN KEY (service) REFERENCES public.service(id);


--
-- PostgreSQL database dump complete
--

