--
-- PostgreSQL database dump
--

-- Dumped from database version 12.3
-- Dumped by pg_dump version 12.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: service; Type: TABLE; Schema: public; Owner: davidrosenberg
--

CREATE TABLE public.service (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    type character varying(8),
    active boolean DEFAULT true NOT NULL
);


ALTER TABLE public.service OWNER TO davidrosenberg;

--
-- Name: service_id_seq; Type: SEQUENCE; Schema: public; Owner: davidrosenberg
--

CREATE SEQUENCE public.service_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.service_id_seq OWNER TO davidrosenberg;

--
-- Name: service_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: davidrosenberg
--

ALTER SEQUENCE public.service_id_seq OWNED BY public.service.id;


--
-- Name: signout; Type: TABLE; Schema: public; Owner: davidrosenberg
--

CREATE TABLE public.signout (
    id integer NOT NULL,
    intern_name character varying(64) NOT NULL,
    intern_callback character varying(16) NOT NULL,
    service integer NOT NULL,
    oncall boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    addtime timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completetime timestamp without time zone,
    starttime timestamp without time zone,
    ipaddress inet DEFAULT '127.0.0.1'::inet NOT NULL,
    hosttimestamp character varying(64) DEFAULT NULL::character varying
);


ALTER TABLE public.signout OWNER TO davidrosenberg;

--
-- Name: signout_id_seq; Type: SEQUENCE; Schema: public; Owner: davidrosenberg
--

CREATE SEQUENCE public.signout_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.signout_id_seq OWNER TO davidrosenberg;

--
-- Name: signout_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: davidrosenberg
--

ALTER SEQUENCE public.signout_id_seq OWNED BY public.signout.id;


--
-- Name: service id; Type: DEFAULT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.service ALTER COLUMN id SET DEFAULT nextval('public.service_id_seq'::regclass);


--
-- Name: signout id; Type: DEFAULT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.signout ALTER COLUMN id SET DEFAULT nextval('public.signout_id_seq'::regclass);


--
-- Data for Name: service; Type: TABLE DATA; Schema: public; Owner: davidrosenberg
--

COPY public.service (id, name, type, active) FROM stdin;
1	Breast, Intern #1	NF9132	t
2	Breast, Intern #2	NF9132	t
3	Breast, Sub-Intern	NF9132	t
4	Breast, APP	NF9132	t
5	GI A, Intern #1	NF9132	t
6	GI A, Intern #2	NF9132	t
7	GI A, Intern #3	NF9132	t
8	GI B, Intern #1	NF9132	t
9	GI B, Intern #2	NF9132	t
10	GI B, Intern #3	NF9132	t
11	GI B, Sub-Intern	NF9132	t
12	STR, Intern #1	NF9133	t
13	STR, Intern #2	NF9133	t
14	STR, Sub-Intern #1	NF9133	t
15	STR, NP	NF9133	t
16	Gen Med, Intern #1	NF9133	t
17	Gen Med, Intern #2	NF9133	t
18	Gen Med, Intern #3	NF9133	t
19	Leukemia A, Intern #1	NF9133	t
20	Leukemia A, Intern #2	NF9133	t
21	Leukemia A, Intern #3	NF9133	t
22	Leukemia A, NP	NF9133	t
23	Leukemia A, Sub-Intern	NF9133	t
24	Leukemia B, Intern #1	NF9133	t
25	Leukemia B, Intern #2	NF9133	t
26	Leukemia B, NP	NF9133	t
27	Leukemia B, Sub-Intern	NF9133	t
28	Lymphoma Green, Intern #1	NF9133	t
29	Lymphoma Green, Intern #2	NF9133	t
30	Lymphoma Green, Intern #3	NF9133	t
31	Lymphoma Green, Intern #3	NF9133	t
32	Lymphona Green, Sub-Intern	NF9133	t
33	GI C, APP #1	NF9132	t
34	GI C, APP #2	NF9132	t
35	GI C, APP #3	NF9132	t
36	GI C, APP #4	NF9132	t
37	GI D, APP #1	NF9132	t
38	GI D, APP #2	NF9132	t
39	GI D, APP #3	NF9132	t
40	GI D, APP #4	NF9132	t
41	GI A, Sub-Intern	NF9132	t
42	Lymphoma Green, APP	NF9133	t
\.


--
-- Data for Name: signout; Type: TABLE DATA; Schema: public; Owner: davidrosenberg
--

COPY public.signout (id, intern_name, intern_callback, service, oncall, active, addtime, completetime, starttime, ipaddress, hosttimestamp) FROM stdin;
2	Roya Nazarian	x6834	18	f	t	2020-10-04 15:52:56.928655	\N	\N	127.0.0.1	\N
3	Brian Cahn	x3327	30	f	t	2020-10-04 16:10:34.937637	\N	\N	127.0.0.1	\N
4	Keara English	x1118	23	f	t	2020-10-04 16:38:08.938457	\N	\N	127.0.0.1	\N
5	Benjamin Schrank	x6925	28	f	t	2020-10-04 16:46:38.93917	\N	\N	127.0.0.1	\N
6	Gaius Baltar	x4283	24	f	t	2020-10-04 16:39:12.939687	\N	\N	127.0.0.1	\N
8	Allison Limmer	x6686	14	f	t	2020-10-04 16:15:56.940665	\N	\N	127.0.0.1	\N
9	Meghan Beatson	x6070	23	f	t	2020-10-04 16:21:17.941086	\N	\N	127.0.0.1	\N
10	Sarah Nocco	x2825	21	f	t	2020-10-04 16:04:17.941665	\N	\N	127.0.0.1	\N
12	McMillian, Matthew	x9246	8	f	t	2020-10-04 16:26:29.942939	\N	\N	127.0.0.1	\N
13	Boomer	x7112	4	f	t	2020-10-04 16:23:56.943488	\N	\N	127.0.0.1	\N
14	Marqueen, Kathryn	x9570	4	f	t	2020-10-04 16:26:01.944119	\N	\N	127.0.0.1	\N
15	Lee Adama	x9884	20	t	t	2020-10-04 17:45:05.944787	\N	\N	127.0.0.1	\N
16	Hannah Schultz	x9641	20	t	t	2020-10-04 16:59:32.945502	\N	\N	127.0.0.1	\N
17	James Winebreak	x3099	29	t	t	2020-10-04 16:52:29.946124	\N	\N	127.0.0.1	\N
18	Mary Smith	x1760	22	t	t	2020-10-04 16:55:23.946714	\N	\N	127.0.0.1	\N
19	James Kirk	x9520	29	t	t	2020-10-04 17:26:32.94711	\N	\N	127.0.0.1	\N
20	Jason Klein	x3455	21	t	t	2020-10-04 17:30:11.947462	\N	\N	127.0.0.1	\N
21	Laura Rosalin	x5624	21	t	t	2020-10-04 17:45:48.947841	\N	\N	127.0.0.1	\N
1	David Rosenberg	7732403395	1	f	f	2020-10-04 15:49:10.039372	2020-10-04 15:55:41.412312	\N	127.0.0.1	\N
22	Leonard Nimoy	1234	7	f	t	2020-10-04 16:46:49.809102	\N	\N	127.0.0.1	\N
7	Christopher Jackson	x6945	8	f	f	2020-10-04 16:04:03.940207	2020-10-04 16:47:15.812931	\N	127.0.0.1	\N
11	Lisa Koenig	x8838	7	f	f	2020-10-04 16:00:05.942411	2020-10-04 16:47:32.266931	\N	127.0.0.1	\N
23	David	12345	5	f	t	2020-10-04 23:11:23.2881	\N	\N	127.0.0.1	\N
24	David	1234	1	f	t	2020-10-04 23:12:26.349377	\N	\N	127.0.0.1	\N
25	David	1234	1	f	t	2020-10-04 23:13:41.258579	\N	\N	127.0.0.1	\N
26	David Rosenberg	1234	1	f	t	2020-10-05 08:26:08.761696	\N	\N	127.0.0.1	\N
27	David Rosenberg	773-240-3395	1	f	t	2020-10-05 08:38:28.668813	\N	\N	127.0.0.1	\N
28	David Rosenberg	1234	1	f	t	2020-10-05 08:39:25.254303	\N	\N	127.0.0.1	\N
29	Greshma	1234	1	f	t	2020-10-05 08:44:12.630957	\N	\N	127.0.0.1	\N
30	David Rosenberg	773-240-3395	3	f	t	2020-10-05 09:14:54.418629	\N	\N	127.0.0.1	\N
31	Greshma	45667	1	f	t	2020-10-05 09:16:05.006964	\N	\N	127.0.0.1	\N
32	Adama	1234	1	f	t	2020-10-05 09:17:00.346099	\N	\N	127.0.0.1	\N
33	David1	1234	1	f	t	2020-10-05 10:42:17.215732	\N	\N	127.0.0.1	\N
34	David1	1234	1	f	t	2020-10-05 10:56:15.279131	\N	\N	127.0.0.1	\N
35	David1	1234	1	f	t	2020-10-05 10:56:34.987669	\N	\N	127.0.0.1	\N
36	David1	1234	1	f	t	2020-10-05 10:56:48.038622	\N	\N	127.0.0.1	\N
37	David1	1234	1	f	t	2020-10-05 11:03:22.817529	\N	\N	127.0.0.1	\N
38	David3	1234	1	f	t	2020-10-05 11:03:22.822649	\N	\N	127.0.0.1	\N
39	David2	1234	1	f	t	2020-10-05 11:03:22.828242	\N	\N	127.0.0.1	\N
40	David4	1234	1	f	t	2020-10-05 11:03:22.84608	\N	\N	127.0.0.1	\N
41	David5	1234	1	f	t	2020-10-05 11:03:22.884412	\N	\N	127.0.0.1	\N
42	David6	1234	1	f	t	2020-10-05 11:03:22.914795	\N	\N	127.0.0.1	\N
43	David7	1234	1	f	t	2020-10-05 11:03:22.933257	\N	\N	127.0.0.1	\N
44	David8	1234	1	f	t	2020-10-05 11:03:22.946738	\N	\N	127.0.0.1	\N
45	David9	1234	1	f	t	2020-10-05 11:03:22.969269	\N	\N	127.0.0.1	\N
46	David10	1234	1	f	t	2020-10-05 11:03:23.000253	\N	\N	127.0.0.1	\N
47	StressTestUser1	1234	1	f	t	2020-10-05 11:15:18.915483	\N	\N	127.0.0.1	\N
48	StressTestUser2	1234	1	f	t	2020-10-05 11:15:18.919947	\N	\N	127.0.0.1	\N
49	StressTestUser1	1234	1	f	t	2020-10-05 11:15:39.172388	\N	\N	127.0.0.1	\N
50	StressTestUser3	1234	1	f	t	2020-10-05 11:15:39.185322	\N	\N	127.0.0.1	\N
51	StressTestUser2	1234	1	f	t	2020-10-05 11:15:39.184874	\N	\N	127.0.0.1	\N
52	StressTestUser4	1234	1	f	t	2020-10-05 11:15:39.194622	\N	\N	127.0.0.1	\N
53	StressTestUser5	1234	1	f	t	2020-10-05 11:15:39.248978	\N	\N	127.0.0.1	\N
54	StressTestUser6	1234	1	f	t	2020-10-05 11:15:39.282896	\N	\N	127.0.0.1	\N
55	StressTestUser8	1234	1	f	t	2020-10-05 11:15:39.305109	\N	\N	127.0.0.1	\N
56	StressTestUser7	1234	1	f	t	2020-10-05 11:15:39.31923	\N	\N	127.0.0.1	\N
57	StressTestUser10	1234	1	f	t	2020-10-05 11:15:39.353866	\N	\N	127.0.0.1	\N
58	StressTestUser9	1234	1	f	t	2020-10-05 11:15:39.374838	\N	\N	127.0.0.1	\N
59	StressTestUser11	1234	1	f	t	2020-10-05 11:15:39.419439	\N	\N	127.0.0.1	\N
60	StressTestUser12	1234	1	f	t	2020-10-05 11:15:39.420067	\N	\N	127.0.0.1	\N
61	StressTestUser13	1234	1	f	t	2020-10-05 11:15:39.437013	\N	\N	127.0.0.1	\N
62	StressTestUser14	1234	1	f	t	2020-10-05 11:15:39.457835	\N	\N	127.0.0.1	\N
63	StressTestUser15	1234	1	f	t	2020-10-05 11:15:39.505085	\N	\N	127.0.0.1	\N
64	StressTestUser16	1234	1	f	t	2020-10-05 11:15:39.524981	\N	\N	127.0.0.1	\N
65	StressTestUser17	1234	1	f	t	2020-10-05 11:15:39.540778	\N	\N	127.0.0.1	\N
66	StressTestUser18	1234	1	f	t	2020-10-05 11:15:39.563408	\N	\N	127.0.0.1	\N
67	StressTestUser19	1234	1	f	t	2020-10-05 11:15:39.602689	\N	\N	127.0.0.1	\N
68	StressTestUser20	1234	1	f	t	2020-10-05 11:15:39.63077	\N	\N	127.0.0.1	\N
69	StressTestUser21	1234	1	f	t	2020-10-05 11:15:39.649739	\N	\N	127.0.0.1	\N
70	StressTestUser22	1234	1	f	t	2020-10-05 11:15:39.653356	\N	\N	127.0.0.1	\N
71	StressTestUser23	1234	1	f	t	2020-10-05 11:15:39.703951	\N	\N	127.0.0.1	\N
72	StressTestUser24	1234	1	f	t	2020-10-05 11:15:39.752973	\N	\N	127.0.0.1	\N
73	StressTestUser25	1234	1	f	t	2020-10-05 11:15:39.754362	\N	\N	127.0.0.1	\N
74	StressTestUser26	1234	1	f	t	2020-10-05 11:15:39.756739	\N	\N	127.0.0.1	\N
75	StressTestUser27	1234	1	f	t	2020-10-05 11:15:39.815451	\N	\N	127.0.0.1	\N
76	StressTestUser28	1234	1	f	t	2020-10-05 11:15:39.817444	\N	\N	127.0.0.1	\N
77	StressTestUser29	1234	1	f	t	2020-10-05 11:15:39.838807	\N	\N	127.0.0.1	\N
78	StressTestUser30	1234	1	f	t	2020-10-05 11:15:39.881176	\N	\N	127.0.0.1	\N
79	StressTestUser31	1234	1	f	t	2020-10-05 11:15:39.918541	\N	\N	127.0.0.1	\N
80	StressTestUser32	1234	1	f	t	2020-10-05 11:15:39.92104	\N	\N	127.0.0.1	\N
81	StressTestUser33	1234	1	f	t	2020-10-05 11:15:39.957296	\N	\N	127.0.0.1	\N
82	StressTestUser34	1234	1	f	t	2020-10-05 11:15:39.991162	\N	\N	127.0.0.1	\N
83	StressTestUser36	1234	1	f	t	2020-10-05 11:15:40.022329	\N	\N	127.0.0.1	\N
84	StressTestUser35	1234	1	f	t	2020-10-05 11:15:40.033902	\N	\N	127.0.0.1	\N
85	StressTestUser37	1234	1	f	t	2020-10-05 11:15:40.055425	\N	\N	127.0.0.1	\N
86	StressTestUser38	1234	1	f	t	2020-10-05 11:15:40.118734	\N	\N	127.0.0.1	\N
87	StressTestUser39	1234	1	f	t	2020-10-05 11:15:40.120432	\N	\N	127.0.0.1	\N
88	StressTestUser40	1234	1	f	t	2020-10-05 11:15:40.121653	\N	\N	127.0.0.1	\N
89	StressTestUser41	1234	1	f	t	2020-10-05 11:15:40.137432	\N	\N	127.0.0.1	\N
90	StressTestUser42	1234	1	f	t	2020-10-05 11:15:40.186749	\N	\N	127.0.0.1	\N
91	StressTestUser43	1234	1	f	t	2020-10-05 11:15:40.203201	\N	\N	127.0.0.1	\N
92	StressTestUser44	1234	1	f	t	2020-10-05 11:15:40.235314	\N	\N	127.0.0.1	\N
93	StressTestUser45	1234	1	f	t	2020-10-05 11:15:40.249082	\N	\N	127.0.0.1	\N
94	StressTestUser46	1234	1	f	t	2020-10-05 11:15:40.28499	\N	\N	127.0.0.1	\N
95	StressTestUser47	1234	1	f	t	2020-10-05 11:15:40.30706	\N	\N	127.0.0.1	\N
96	StressTestUser48	1234	1	f	t	2020-10-05 11:15:40.340252	\N	\N	127.0.0.1	\N
97	StressTestUser49	1234	1	f	t	2020-10-05 11:15:40.365036	\N	\N	127.0.0.1	\N
98	StressTestUser50	1234	1	f	t	2020-10-05 11:15:40.382013	\N	\N	127.0.0.1	\N
99	StressTestUser51	1234	1	f	t	2020-10-05 11:15:40.41632	\N	\N	127.0.0.1	\N
100	StressTestUser52	1234	1	f	t	2020-10-05 11:15:40.467086	\N	\N	127.0.0.1	\N
101	StressTestUser53	1234	1	f	t	2020-10-05 11:15:40.471684	\N	\N	127.0.0.1	\N
102	StressTestUser54	1234	1	f	t	2020-10-05 11:15:40.484889	\N	\N	127.0.0.1	\N
103	StressTestUser55	1234	1	f	t	2020-10-05 11:15:40.566929	\N	\N	127.0.0.1	\N
104	StressTestUser56	1234	1	f	t	2020-10-05 11:15:40.569157	\N	\N	127.0.0.1	\N
105	StressTestUser57	1234	1	f	t	2020-10-05 11:15:40.572795	\N	\N	127.0.0.1	\N
106	StressTestUser58	1234	1	f	t	2020-10-05 11:15:40.617602	\N	\N	127.0.0.1	\N
107	StressTestUser59	1234	1	f	t	2020-10-05 11:15:40.655779	\N	\N	127.0.0.1	\N
108	StressTestUser60	1234	1	f	t	2020-10-05 11:15:40.68397	\N	\N	127.0.0.1	\N
109	StressTestUser61	1234	1	f	t	2020-10-05 11:15:40.686274	\N	\N	127.0.0.1	\N
110	StressTestUser62	1234	1	f	t	2020-10-05 11:15:40.715783	\N	\N	127.0.0.1	\N
111	StressTestUser63	1234	1	f	t	2020-10-05 11:15:40.736655	\N	\N	127.0.0.1	\N
112	StressTestUser64	1234	1	f	t	2020-10-05 11:15:40.787788	\N	\N	127.0.0.1	\N
113	StressTestUser65	1234	1	f	t	2020-10-05 11:15:40.797264	\N	\N	127.0.0.1	\N
114	StressTestUser66	1234	1	f	t	2020-10-05 11:15:40.817362	\N	\N	127.0.0.1	\N
115	StressTestUser67	1234	1	f	t	2020-10-05 11:15:40.823768	\N	\N	127.0.0.1	\N
116	StressTestUser68	1234	1	f	t	2020-10-05 11:15:40.869063	\N	\N	127.0.0.1	\N
117	StressTestUser69	1234	1	f	t	2020-10-05 11:15:40.902757	\N	\N	127.0.0.1	\N
118	StressTestUser70	1234	1	f	t	2020-10-05 11:15:40.917154	\N	\N	127.0.0.1	\N
119	StressTestUser71	1234	1	f	t	2020-10-05 11:15:40.935069	\N	\N	127.0.0.1	\N
120	StressTestUser72	1234	1	f	t	2020-10-05 11:15:40.986265	\N	\N	127.0.0.1	\N
121	StressTestUser75	1234	1	f	t	2020-10-05 11:15:41.03151	\N	\N	127.0.0.1	\N
122	StressTestUser74	1234	1	f	t	2020-10-05 11:15:41.031383	\N	\N	127.0.0.1	\N
123	StressTestUser73	1234	1	f	t	2020-10-05 11:15:41.033113	\N	\N	127.0.0.1	\N
124	StressTestUser76	1234	1	f	t	2020-10-05 11:15:41.069665	\N	\N	127.0.0.1	\N
125	StressTestUser77	1234	1	f	t	2020-10-05 11:15:41.091367	\N	\N	127.0.0.1	\N
126	StressTestUser78	1234	1	f	t	2020-10-05 11:15:41.137332	\N	\N	127.0.0.1	\N
127	StressTestUser79	1234	1	f	t	2020-10-05 11:15:41.174506	\N	\N	127.0.0.1	\N
128	StressTestUser80	1234	1	f	t	2020-10-05 11:15:41.183732	\N	\N	127.0.0.1	\N
129	StressTestUser81	1234	1	f	t	2020-10-05 11:15:41.190543	\N	\N	127.0.0.1	\N
130	StressTestUser82	1234	1	f	t	2020-10-05 11:15:41.237045	\N	\N	127.0.0.1	\N
131	StressTestUser83	1234	1	f	t	2020-10-05 11:15:41.267948	\N	\N	127.0.0.1	\N
132	StressTestUser84	1234	1	f	t	2020-10-05 11:15:41.302884	\N	\N	127.0.0.1	\N
133	StressTestUser85	1234	1	f	t	2020-10-05 11:15:41.305595	\N	\N	127.0.0.1	\N
134	StressTestUser86	1234	1	f	t	2020-10-05 11:15:41.352886	\N	\N	127.0.0.1	\N
135	StressTestUser87	1234	1	f	t	2020-10-05 11:15:41.353475	\N	\N	127.0.0.1	\N
136	StressTestUser88	1234	1	f	t	2020-10-05 11:15:41.421334	\N	\N	127.0.0.1	\N
137	StressTestUser89	1234	1	f	t	2020-10-05 11:15:41.420054	\N	\N	127.0.0.1	\N
138	StressTestUser90	1234	1	f	t	2020-10-05 11:15:41.434924	\N	\N	127.0.0.1	\N
139	StressTestUser91	1234	1	f	t	2020-10-05 11:15:41.452562	\N	\N	127.0.0.1	\N
140	StressTestUser92	1234	1	f	t	2020-10-05 11:15:41.506454	\N	\N	127.0.0.1	\N
141	StressTestUser93	1234	1	f	t	2020-10-05 11:15:41.521586	\N	\N	127.0.0.1	\N
142	StressTestUser94	1234	1	f	t	2020-10-05 11:15:41.536837	\N	\N	127.0.0.1	\N
143	StressTestUser95	1234	1	f	t	2020-10-05 11:15:41.567751	\N	\N	127.0.0.1	\N
144	StressTestUser96	1234	1	f	t	2020-10-05 11:15:41.585388	\N	\N	127.0.0.1	\N
145	StressTestUser97	1234	1	f	t	2020-10-05 11:15:41.616793	\N	\N	127.0.0.1	\N
146	StressTestUser98	1234	1	f	t	2020-10-05 11:15:41.639626	\N	\N	127.0.0.1	\N
147	StressTestUser99	1234	1	f	t	2020-10-05 11:15:41.672941	\N	\N	127.0.0.1	\N
148	StressTestUser100	1234	1	f	t	2020-10-05 11:15:41.689695	\N	\N	127.0.0.1	\N
149	StressTestUser1	1234	1	f	t	2020-10-05 11:16:33.522645	\N	\N	127.0.0.1	\N
150	StressTestUser1	1234	1	f	t	2020-10-05 11:17:05.675732	\N	\N	127.0.0.1	\N
151	David	1234	4	f	t	2020-10-11 19:38:17.135521	\N	\N	127.0.0.1	\N
153	David	1234	4	f	t	2020-10-11 19:10:46.7277	\N	\N	127.0.0.1	\N
154	David &Rosenberg	12345	4	f	t	2020-10-11 19:12:03.161133	\N	\N	127.0.0.1	\N
155	David<p>Rosenberg	1234	4	f	t	2020-10-11 19:15:51.532978	\N	\N	127.0.0.1	\N
156	David<!--Rosenberg	1234	4	f	t	2020-10-11 19:16:06.857607	\N	\N	127.0.0.1	\N
157	David<em> Rosenberg</em>	O'Connel "1234"	2	f	t	2020-10-11 19:21:41.841231	\N	\N	127.0.0.1	\N
152	Matt O'Connel	1234	4	f	f	2020-10-11 19:10:38.188674	2020-10-11 19:21:52.904231	\N	127.0.0.1	\N
\.


--
-- Name: service_id_seq; Type: SEQUENCE SET; Schema: public; Owner: davidrosenberg
--

SELECT pg_catalog.setval('public.service_id_seq', 42, true);


--
-- Name: signout_id_seq; Type: SEQUENCE SET; Schema: public; Owner: davidrosenberg
--

SELECT pg_catalog.setval('public.signout_id_seq', 157, true);


--
-- Name: service service_pkey; Type: CONSTRAINT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.service
    ADD CONSTRAINT service_pkey PRIMARY KEY (id);


--
-- Name: signout signout_pkey; Type: CONSTRAINT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.signout
    ADD CONSTRAINT signout_pkey PRIMARY KEY (id);


--
-- Name: signout signout_service_fkey; Type: FK CONSTRAINT; Schema: public; Owner: davidrosenberg
--

ALTER TABLE ONLY public.signout
    ADD CONSTRAINT signout_service_fkey FOREIGN KEY (service) REFERENCES public.service(id);


--
-- PostgreSQL database dump complete
--

